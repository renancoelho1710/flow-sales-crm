import { ModulePlaceholder } from "@/components/dashboard/ModulePlaceholder";
export default function Page() { return <ModulePlaceholder titulo="Agenda" descricao="Agenda preparada para visitas, test drives, retornos e compromissos criados no CRM." acoes={[{ label: "Ver leads agendados", href: "/dashboard/leads?etapa=agendado" }]} />; }
