import { ModulePlaceholder } from "@/components/dashboard/ModulePlaceholder";
export default function Page() { return <ModulePlaceholder titulo="Relatórios" descricao="Relatórios preparados para análise operacional, vendas, leads, ligações, campanhas e exportações." acoes={[{ label: "Dashboard", href: "/dashboard" }, { label: "Leads", href: "/dashboard/leads" }]} />; }
