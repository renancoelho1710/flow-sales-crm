import { createClient } from "@/lib/supabase/server";
import { DashboardClient } from "./DashboardClient";

async function contar(supabase: Awaited<ReturnType<typeof createClient>>, tabela: string, filtro?: (query: any) => any) {
  let query = supabase.from(tabela).select("id", { count: "exact", head: true });
  if (filtro) query = filtro(query);
  const { count } = await query;
  return count || 0;
}

export default async function DashboardPage() {
  const supabase = await createClient();
  const hojeInicio = new Date();
  hojeInicio.setHours(0, 0, 0, 0);
  const hojeFim = new Date();
  hojeFim.setHours(23, 59, 59, 999);

  const [leadsAtivos, agendamentosHoje, visitasLoja, vendasPendentes, leadsSemContato, leadsEmContato, leadsAgendados, leadsValidados, unidades] = await Promise.all([
    contar(supabase, "leads", (q) => q.eq("arquivado", false)),
    contar(supabase, "lead_agendamentos", (q) => q.gte("inicio", hojeInicio.toISOString()).lte("inicio", hojeFim.toISOString())),
    contar(supabase, "lead_agendamentos", (q) => q.eq("tipo", "visita")),
    contar(supabase, "leads", (q) => q.eq("venda_pendente_validacao", true).eq("venda_validada", false)),
    contar(supabase, "leads", (q) => q.eq("arquivado", false).in("etapa", ["novo", "primeiro_contato", "segundo_contato"])),
    contar(supabase, "leads", (q) => q.eq("etapa", "em_atendimento")),
    contar(supabase, "leads", (q) => q.eq("etapa", "agendado")),
    contar(supabase, "leads", (q) => q.eq("venda_validada", true)),
    supabase.from("unidades").select("id, nome, codigo").eq("ativa", true).order("codigo"),
  ]);

  return <DashboardClient dados={{
    leadsAtivos,
    agendamentosHoje,
    visitasLoja,
    vendasPendentes,
    leadsSemContato,
    leadsEmContato,
    leadsAgendados,
    leadsValidados,
    unidades: unidades.data || [],
  }} />;
}
