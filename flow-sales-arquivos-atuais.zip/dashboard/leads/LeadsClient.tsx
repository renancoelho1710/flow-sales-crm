"use client";

import { FormEvent, useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import { CalendarDays, Columns3, Download, Filter, MessageCircle, Phone, Plus, Search, Send, Star, X } from "lucide-react";
import { createClient } from "@/lib/supabase/client";
import { ActionMenu } from "@/components/dashboard/ActionMenu";
import { StatusBadge } from "@/components/dashboard/StatusBadge";
import { AvatarStatus } from "@/components/dashboard/AvatarStatus";

type Lead = {
  id: string;
  nome: string;
  telefone: string;
  email: string | null;
  origem: string | null;
  campanha: string | null;
  status: string;
  etapa: string;
  temperatura: string;
  veiculo_interesse: string | null;
  data_ultimo_contato: string | null;
  data_proxima_acao: string | null;
  criado_em: string;
  c2s_internal_id?: number | null;
  venda_pendente_validacao?: boolean;
  venda_validada?: boolean;
  responsavel?: { id: string; nome: string; email: string; avatar_url?: string | null } | null;
  unidade?: { id: string; nome: string; codigo: string } | null;
};

type Usuario = { id: string; nome: string; email: string; perfil: string; avatar_url?: string | null; ativo: boolean; recebe_leads: boolean };
type Unidade = { id: string; nome: string; codigo: string };

function formatarData(valor?: string | null) {
  if (!valor) return "—";
  return new Intl.DateTimeFormat("pt-BR", { day: "2-digit", month: "2-digit", year: "2-digit", hour: "2-digit", minute: "2-digit" }).format(new Date(valor));
}

function normalizar(valor: unknown) {
  return String(valor || "").toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");
}

function badgeEtapa(etapa: string) {
  const mapa: Record<string, { label: string; tipo: "blue" | "green" | "red" | "gray" | "amber" | "purple" }> = {
    novo: { label: "Sem contato", tipo: "red" },
    em_atendimento: { label: "Em contato", tipo: "blue" },
    agendado: { label: "Agendado", tipo: "purple" },
    compareceu: { label: "Visitou loja", tipo: "green" },
    venda_pendente_validacao: { label: "Venda pendente", tipo: "amber" },
    venda_validada: { label: "Venda validada", tipo: "green" },
  };
  return mapa[etapa] || { label: etapa, tipo: "gray" as const };
}

export function LeadsClient({ leads, usuarios, unidades, perfilAtual, params }: { leads: Lead[]; usuarios: Usuario[]; unidades: Unidade[]; perfilAtual: string; params: Record<string, string | string[] | undefined> }) {
  const router = useRouter();
  const supabase = createClient();
  const [busca, setBusca] = useState(String(params.busca || ""));
  const [loja, setLoja] = useState(String(params.loja || "todas"));
  const [responsavel, setResponsavel] = useState("todos");
  const [status, setStatus] = useState("todos");
  const [temperatura, setTemperatura] = useState(String(params.temperatura || "todos"));
  const [origem, setOrigem] = useState("todas");
  const [leadSelecionado, setLeadSelecionado] = useState<Lead | null>(leads[0] || null);
  const [modalAgendar, setModalAgendar] = useState(false);
  const [modalObs, setModalObs] = useState(false);
  const [mensagem, setMensagem] = useState("");

  const origens = useMemo(() => Array.from(new Set(leads.map((lead) => lead.origem).filter(Boolean))) as string[], [leads]);

  const filtrados = useMemo(() => {
    const termo = normalizar(busca);
    return leads.filter((lead) => {
      const texto = normalizar([lead.nome, lead.telefone, lead.email, lead.origem, lead.veiculo_interesse, lead.responsavel?.nome].join(" "));
      const buscaOk = !termo || texto.includes(termo);
      const lojaOk = loja === "todas" || lead.unidade?.id === loja;
      const respOk = responsavel === "todos" || lead.responsavel?.id === responsavel;
      const statusOk = status === "todos" || lead.etapa === status || (status === "venda_pendente" && lead.venda_pendente_validacao) || (status === "venda_validada" && lead.venda_validada);
      const tempOk = temperatura === "todos" || lead.temperatura === temperatura;
      const origemOk = origem === "todas" || lead.origem === origem;
      return buscaOk && lojaOk && respOk && statusOk && tempOk && origemOk;
    });
  }, [leads, busca, loja, responsavel, status, temperatura, origem]);

  const metrics = {
    ativos: leads.length,
    emContato: leads.filter((l) => l.etapa === "em_atendimento").length,
    agendados: leads.filter((l) => l.etapa === "agendado").length,
    semContato: leads.filter((l) => ["novo", "primeiro_contato", "segundo_contato"].includes(l.etapa)).length,
    vendasPendentes: leads.filter((l) => l.venda_pendente_validacao && !l.venda_validada).length,
  };

  function exportar() {
    const csv = [["Nome", "Telefone", "Email", "Origem", "Veiculo", "Responsavel"], ...filtrados.map((l) => [l.nome, l.telefone, l.email || "", l.origem || "", l.veiculo_interesse || "", l.responsavel?.nome || ""])].map((linha) => linha.map((celula) => `"${String(celula).replace(/"/g, '""')}"`).join(";")).join("\n");
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "leads-flow-sales.csv";
    a.click();
    URL.revokeObjectURL(url);
  }

  function abrirWhatsapp(lead: Lead) {
    const telefone = String(lead.telefone || "").replace(/\D/g, "");
    const texto = encodeURIComponent(`Olá ${lead.nome}, tudo bem? Aqui é da Azul Veículos. Vi seu interesse em ${lead.veiculo_interesse || "um veículo"}.`);
    window.open(`https://wa.me/55${telefone}?text=${texto}`, "_blank");
  }

  async function registrarInteracao(tipo: string, observacao: string) {
    if (!leadSelecionado) return;
    await supabase.from("lead_interacoes").insert({ lead_id: leadSelecionado.id, tipo, canal: "sistema", observacao });
    setMensagem("Registro salvo.");
    setTimeout(() => setMensagem(""), 1800);
  }

  async function agendar(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!leadSelecionado) return;
    const form = new FormData(event.currentTarget);
    const inicio = String(form.get("inicio"));
    const observacao = String(form.get("observacao") || "");
    await supabase.from("lead_agendamentos").insert({ lead_id: leadSelecionado.id, titulo: "Agendamento", tipo: "visita", inicio, observacao });
    await registrarInteracao("agendamento", `Agendamento criado para ${formatarData(inicio)}.`);
    setModalAgendar(false);
  }

  async function salvarObs(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const form = new FormData(event.currentTarget);
    await registrarInteracao("observacao", String(form.get("observacao") || ""));
    setModalObs(false);
  }

  return (
    <>
      <div className="mb-5 flex flex-col gap-4 lg:flex-row lg:items-end lg:justify-between">
        <div>
          <h1 className="text-3xl font-black tracking-tight text-slate-950">Gestão de Leads</h1>
          <p className="mt-1 text-sm font-medium text-slate-500">Acompanhe contatos, oportunidades e próximos passos da operação.</p>
        </div>
        <div className="flex flex-wrap gap-3">
          <button onClick={exportar} className="inline-flex h-11 items-center gap-2 rounded-xl border border-slate-200 bg-white px-5 text-sm font-black text-slate-700 transition hover:bg-slate-50"><Download className="h-4 w-4" /> Exportar</button>
          {perfilAtual !== "colaborador" ? <button onClick={() => router.push("/dashboard/c2s")} className="inline-flex h-11 items-center gap-2 rounded-xl border border-slate-200 bg-white px-5 text-sm font-black text-slate-700 transition hover:bg-slate-50">Importar</button> : null}
          {perfilAtual !== "colaborador" ? <button onClick={() => router.push("/dashboard/usuarios")} className="inline-flex h-11 items-center gap-2 rounded-xl bg-blue-700 px-5 text-sm font-black text-white shadow-lg shadow-blue-700/20 transition hover:bg-blue-800"><Plus className="h-4 w-4" /> Usuários</button> : null}
        </div>
      </div>

      <section className="mb-4 grid gap-3 xl:grid-cols-[1fr_1fr_1fr_1fr_1fr_1.5fr_auto]">
        <Select value={loja} onChange={setLoja} options={[{ value: "todas", label: "Todas as lojas" }, ...unidades.map((u) => ({ value: u.id, label: u.nome }))]} />
        <Select value={responsavel} onChange={setResponsavel} options={[{ value: "todos", label: "Responsável: todos" }, ...usuarios.map((u) => ({ value: u.id, label: u.nome }))]} />
        <Select value={status} onChange={setStatus} options={[{ value: "todos", label: "Status: todos" }, { value: "novo", label: "Sem contato" }, { value: "em_atendimento", label: "Em contato" }, { value: "agendado", label: "Agendado" }, { value: "venda_pendente", label: "Venda pendente" }, { value: "venda_validada", label: "Venda validada" }]} />
        <Select value={temperatura} onChange={setTemperatura} options={[{ value: "todos", label: "Temperatura: todos" }, { value: "frio", label: "Frio" }, { value: "morno", label: "Morno" }, { value: "quente", label: "Quente" }]} />
        <Select value={origem} onChange={setOrigem} options={[{ value: "todas", label: "Origem: todas" }, ...origens.map((o) => ({ value: o, label: o }))]} />
        <div className="relative"><Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" /><input value={busca} onChange={(e) => setBusca(e.target.value)} placeholder="Buscar lead..." className="h-11 w-full rounded-xl border border-slate-200 bg-white pl-10 pr-3 text-sm font-semibold outline-none focus:border-blue-600 focus:ring-4 focus:ring-blue-100" /></div>
        <button onClick={() => { setBusca(""); setLoja("todas"); setResponsavel("todos"); setStatus("todos"); setTemperatura("todos"); setOrigem("todas"); }} className="h-11 rounded-xl border border-slate-200 bg-white px-4 text-sm font-black text-slate-700 hover:bg-slate-50">Limpar filtros</button>
      </section>

      <section className="mb-4 grid gap-4 md:grid-cols-2 xl:grid-cols-6">
        <Card label="Leads ativos" value={metrics.ativos} onClick={() => setStatus("todos")} />
        <Card label="Em contato" value={metrics.emContato} onClick={() => setStatus("em_atendimento")} />
        <Card label="Agendados" value={metrics.agendados} onClick={() => setStatus("agendado")} />
        <Card label="Sem contato" value={metrics.semContato} onClick={() => setStatus("novo")} color="red" />
        <Card label="Vendas pendentes" value={metrics.vendasPendentes} onClick={() => setStatus("venda_pendente")} color="amber" />
        <Card label="Conversão do mês" valueText="18,6%" onClick={() => router.push("/dashboard/relatorios")} color="green" />
      </section>

      <section className="grid gap-5 xl:grid-cols-[1.15fr_0.95fr]">
        <div className="rounded-2xl border border-slate-200 bg-white shadow-sm">
          <div className="flex items-center justify-between border-b border-slate-200 px-5 py-4"><div className="flex gap-5 text-sm font-black"><button onClick={() => setStatus("todos")} className="text-blue-700">Todos <span className="ml-2 rounded-full bg-slate-100 px-2 py-1 text-slate-600">{leads.length}</span></button><button onClick={() => setResponsavel("todos")} className="text-slate-500">Meus leads</button><button onClick={() => setTemperatura("quente")} className="text-slate-500">Quentes</button></div><button onClick={() => alert("Colunas preparadas para personalização por usuário.")} className="inline-flex items-center gap-2 rounded-xl border border-slate-200 px-3 py-2 text-sm font-black text-slate-700"><Columns3 className="h-4 w-4" /> Colunas</button></div>
          <div className="overflow-x-auto">
            <table className="w-full min-w-[900px] text-left text-sm">
              <thead className="bg-slate-50 text-xs font-black uppercase tracking-[0.14em] text-slate-500"><tr><th className="px-5 py-4">Lead</th><th className="px-5 py-4">Origem</th><th className="px-5 py-4">Veículo de interesse</th><th className="px-5 py-4">Último contato</th><th className="px-5 py-4">Responsável</th><th className="px-5 py-4">Status</th><th className="px-5 py-4">Próxima ação</th></tr></thead>
              <tbody className="divide-y divide-slate-100">
                {filtrados.map((lead) => { const badge = badgeEtapa(lead.etapa); return <tr key={lead.id} onClick={() => setLeadSelecionado(lead)} className={`cursor-pointer transition hover:bg-blue-50/40 ${leadSelecionado?.id === lead.id ? "bg-blue-50" : ""}`}><td className="px-5 py-4"><p className="font-black text-blue-700">{lead.nome}</p><p className="mt-1 text-xs font-semibold text-slate-500">{lead.telefone}</p></td><td className="px-5 py-4"><StatusBadge texto={lead.origem || "—"} tipo="gray" /></td><td className="max-w-[220px] px-5 py-4 font-bold text-slate-700"><span className="line-clamp-2">{lead.veiculo_interesse || "—"}</span></td><td className="px-5 py-4 text-slate-600">{formatarData(lead.data_ultimo_contato || lead.criado_em)}</td><td className="px-5 py-4 text-slate-700">{lead.responsavel?.nome || "Sem responsável"}</td><td className="px-5 py-4"><StatusBadge texto={badge.label} tipo={badge.tipo} /></td><td className="px-5 py-4"><div className="flex items-center gap-2"><button onClick={(e) => { e.stopPropagation(); window.location.href = `tel:${lead.telefone}`; }} className="font-black text-blue-700">Ligar</button><button onClick={(e) => { e.stopPropagation(); abrirWhatsapp(lead); }} className="font-black text-emerald-700">WhatsApp</button></div></td></tr>; })}
              </tbody>
            </table>
          </div>
          <div className="flex items-center justify-between border-t border-slate-200 px-5 py-4 text-sm font-bold text-slate-500"><span>Mostrando {filtrados.length} de {leads.length} leads</span><div className="flex gap-2"><button className="h-9 rounded-xl border border-slate-200 px-3">1</button><button className="h-9 rounded-xl border border-slate-200 px-3">2</button></div></div>
        </div>

        <aside className="space-y-4">
          {leadSelecionado ? <LeadDetalhe lead={leadSelecionado} onLigar={() => window.location.href = `tel:${leadSelecionado.telefone}`} onWhatsapp={() => abrirWhatsapp(leadSelecionado)} onAgendar={() => setModalAgendar(true)} onObs={() => setModalObs(true)} /> : <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm" />}
          {mensagem ? <div className="rounded-xl border border-emerald-200 bg-emerald-50 p-4 text-sm font-black text-emerald-700">{mensagem}</div> : null}
        </aside>
      </section>

      {modalAgendar && leadSelecionado ? <Modal titulo="Agendar visita" onClose={() => setModalAgendar(false)}><form onSubmit={agendar} className="grid gap-4"><input name="inicio" type="datetime-local" required className="h-11 rounded-xl border border-slate-300 px-3" /><textarea name="observacao" placeholder="Observação" className="min-h-24 rounded-xl border border-slate-300 p-3" /><button className="h-11 rounded-xl bg-blue-700 font-black text-white">Salvar agendamento</button></form></Modal> : null}
      {modalObs && leadSelecionado ? <Modal titulo="Registrar observação" onClose={() => setModalObs(false)}><form onSubmit={salvarObs} className="grid gap-4"><textarea name="observacao" required placeholder="Digite a observação" className="min-h-28 rounded-xl border border-slate-300 p-3" /><button className="h-11 rounded-xl bg-blue-700 font-black text-white">Salvar observação</button></form></Modal> : null}
    </>
  );
}

function Select({ value, onChange, options }: { value: string; onChange: (v: string) => void; options: { value: string; label: string }[] }) { return <select value={value} onChange={(e) => onChange(e.target.value)} className="h-11 rounded-xl border border-slate-200 bg-white px-3 text-sm font-bold text-slate-700 outline-none focus:border-blue-600 focus:ring-4 focus:ring-blue-100">{options.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}</select>; }
function Card({ label, value, valueText, color = "blue", onClick }: { label: string; value?: number; valueText?: string; color?: "blue" | "red" | "amber" | "green"; onClick: () => void }) { const cls = { blue: "bg-blue-50 text-blue-700", red: "bg-red-50 text-red-700", amber: "bg-amber-50 text-amber-700", green: "bg-emerald-50 text-emerald-700" }[color]; return <button onClick={onClick} className="rounded-2xl border border-slate-200 bg-white p-5 text-left shadow-sm transition hover:-translate-y-0.5 hover:shadow-md"><div className={`mb-3 h-12 w-12 rounded-2xl ${cls}`} /><p className="text-sm font-black text-slate-500">{label}</p><p className="mt-2 text-3xl font-black text-slate-950">{valueText || new Intl.NumberFormat("pt-BR").format(value || 0)}</p></button>; }
function LeadDetalhe({ lead, onLigar, onWhatsapp, onAgendar, onObs }: { lead: Lead; onLigar: () => void; onWhatsapp: () => void; onAgendar: () => void; onObs: () => void }) { const badge = badgeEtapa(lead.etapa); return <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm"><div className="mb-4 flex items-start justify-between"><div><h2 className="text-2xl font-black text-slate-950">{lead.nome} <Star className="inline h-4 w-4 text-slate-300" /></h2><p className="mt-1 text-sm font-semibold text-slate-500">{lead.telefone} · {lead.email || "sem e-mail"}</p></div><StatusBadge texto={badge.label} tipo={badge.tipo} /></div><div className="mb-4 grid grid-cols-2 gap-3 text-sm"><Info label="Loja" value={lead.unidade?.nome || "—"} /><Info label="Origem" value={lead.origem || "—"} /><Info label="Veículo" value={lead.veiculo_interesse || "—"} /><Info label="Responsável" value={lead.responsavel?.nome || "Sem responsável"} /></div><div className="mb-4 flex flex-wrap gap-2"><button onClick={onLigar} className="inline-flex h-10 items-center gap-2 rounded-xl border border-slate-200 px-3 text-sm font-black text-slate-700"><Phone className="h-4 w-4" /> Ligar</button><button onClick={onWhatsapp} className="inline-flex h-10 items-center gap-2 rounded-xl border border-emerald-200 bg-emerald-50 px-3 text-sm font-black text-emerald-700"><MessageCircle className="h-4 w-4" /> WhatsApp</button><button onClick={onAgendar} className="inline-flex h-10 items-center gap-2 rounded-xl border border-slate-200 px-3 text-sm font-black text-slate-700"><CalendarDays className="h-4 w-4" /> Agendar</button><button onClick={onObs} className="inline-flex h-10 items-center gap-2 rounded-xl border border-slate-200 px-3 text-sm font-black text-slate-700"><Send className="h-4 w-4" /> Observação</button></div><div className="rounded-2xl border border-slate-100 bg-slate-50 p-4"><h3 className="mb-3 font-black text-slate-950">Linha do tempo</h3><p className="text-sm font-semibold text-slate-600">Lead recebido em {formatarData(lead.criado_em)}.</p></div></div>; }
function Info({ label, value }: { label: string; value: string }) { return <div><p className="text-xs font-black uppercase tracking-[0.12em] text-slate-400">{label}</p><p className="mt-1 font-bold text-slate-800 line-clamp-2">{value}</p></div>; }
function Modal({ titulo, children, onClose }: { titulo: string; children: React.ReactNode; onClose: () => void }) { return <div className="fixed inset-0 z-[9998] flex items-center justify-center bg-slate-950/30 px-4 backdrop-blur-sm"><div className="w-full max-w-lg rounded-2xl bg-white p-6 shadow-2xl"><div className="mb-5 flex items-center justify-between"><h2 className="text-xl font-black text-slate-950">{titulo}</h2><button onClick={onClose}><X className="h-5 w-5" /></button></div>{children}</div></div>; }
