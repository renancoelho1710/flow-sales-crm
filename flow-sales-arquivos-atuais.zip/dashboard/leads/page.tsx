import { createClient } from "@/lib/supabase/server";
import { LeadsClient } from "./LeadsClient";

export default async function LeadsPage({ searchParams }: { searchParams?: Promise<Record<string, string | string[] | undefined>> }) {
  const supabase = await createClient();
  const params = (await searchParams) || {};

  const { data: usuario } = await supabase
    .from("usuarios_internos")
    .select("id, perfil")
    .eq("auth_user_id", (await supabase.auth.getUser()).data.user?.id)
    .single();

  const { data: leads } = await supabase
    .from("leads")
    .select("id, nome, telefone, email, origem, campanha, status, etapa, temperatura, veiculo_interesse, data_ultimo_contato, data_proxima_acao, criado_em, atualizado_em, c2s_internal_id, venda_pendente_validacao, venda_validada, responsavel:responsavel_id(id,nome,email,avatar_url), unidade:unidade_id(id,nome,codigo)")
    .eq("arquivado", false)
    .order("criado_em", { ascending: false })
    .limit(200);

  const { data: usuarios } = await supabase
    .from("usuarios_internos")
    .select("id, nome, email, perfil, avatar_url, ativo, recebe_leads")
    .eq("ativo", true)
    .order("nome");

  const { data: unidades } = await supabase
    .from("unidades")
    .select("id, nome, codigo")
    .eq("ativa", true)
    .order("codigo");

  return <LeadsClient leads={(leads || []) as any} usuarios={usuarios || []} unidades={unidades || []} perfilAtual={usuario?.perfil || "colaborador"} params={params} />;
}
