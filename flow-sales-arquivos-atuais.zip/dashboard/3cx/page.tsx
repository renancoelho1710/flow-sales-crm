import { ModulePlaceholder } from "@/components/dashboard/ModulePlaceholder";
export default function Page() { return <ModulePlaceholder titulo="Controle 3CX" descricao="Monitor preparado para ligações, classificação, status operacional automático e histórico de chamadas." acoes={[{ label: "Ver leads", href: "/dashboard/leads" }]} />; }
