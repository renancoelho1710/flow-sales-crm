import { ModulePlaceholder } from "@/components/dashboard/ModulePlaceholder";
export default function Page() { return <ModulePlaceholder titulo="Campanhas" descricao="Área preparada para campanhas, mensagens, origens e acompanhamento por desempenho." acoes={[{ label: "Ver leads por origem", href: "/dashboard/leads" }]} />; }
