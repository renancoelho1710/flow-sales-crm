import { ModulePlaceholder } from "@/components/dashboard/ModulePlaceholder";
export default function Page() { return <ModulePlaceholder titulo="Configurações" descricao="Configurações preparadas para preferências de tema, aparência, integrações e regras do sistema." acoes={[{ label: "Usuários", href: "/dashboard/usuarios" }]} />; }
