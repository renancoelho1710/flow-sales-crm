import { ModulePlaceholder } from "@/components/dashboard/ModulePlaceholder";
export default function Page() { return <ModulePlaceholder titulo="Simulador" descricao="Simulador preparado para propostas, financiamento e vínculo com o lead selecionado." acoes={[{ label: "Selecionar lead", href: "/dashboard/leads" }]} />; }
