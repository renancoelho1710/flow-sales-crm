"use client";

import { useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import { AlertTriangle, BarChart3, CalendarDays, Car, CheckCircle2, DollarSign, Download, Filter, MoreVertical, Store, UsersRound } from "lucide-react";
import { ActionMenu } from "@/components/dashboard/ActionMenu";

type DashboardDados = {
  leadsAtivos: number;
  agendamentosHoje: number;
  visitasLoja: number;
  vendasPendentes: number;
  leadsSemContato: number;
  leadsEmContato: number;
  leadsAgendados: number;
  leadsValidados: number;
  unidades: { id: string; nome: string; codigo: string }[];
};

function formatarNumero(valor: number) {
  return new Intl.NumberFormat("pt-BR").format(valor || 0);
}

function percent(valor: number, total: number) {
  if (!total) return 0;
  return Math.min(100, Math.round((valor / total) * 100));
}

export function DashboardClient({ dados }: { dados: DashboardDados }) {
  const router = useRouter();
  const [modal, setModal] = useState<{ titulo: string; descricao: string; href?: string } | null>(null);
  const [periodo, setPeriodo] = useState("diario");

  const funil = useMemo(() => [
    { label: "Morno", valor: dados.leadsAtivos, cor: "bg-blue-100 text-blue-700", href: "/dashboard/leads?temperatura=morno" },
    { label: "Em contato", valor: dados.leadsEmContato, cor: "bg-sky-100 text-sky-700", href: "/dashboard/leads?etapa=em_atendimento" },
    { label: "Agendado", valor: dados.leadsAgendados, cor: "bg-purple-100 text-purple-700", href: "/dashboard/leads?etapa=agendado" },
    { label: "Venda pendente", valor: dados.vendasPendentes, cor: "bg-amber-100 text-amber-700", href: "/dashboard/leads?filtro=venda_pendente" },
    { label: "Venda validada", valor: dados.leadsValidados, cor: "bg-emerald-100 text-emerald-700", href: "/dashboard/leads?filtro=venda_validada" },
  ], [dados]);

  const chart = [
    { dia: "16 Mai", leads: Math.max(2, Math.round(dados.leadsAtivos * 0.12)), agenda: Math.max(1, Math.round(dados.agendamentosHoje * 0.4)) },
    { dia: "17 Mai", leads: Math.max(3, Math.round(dados.leadsAtivos * 0.16)), agenda: Math.max(1, Math.round(dados.agendamentosHoje * 0.6)) },
    { dia: "18 Mai", leads: Math.max(2, Math.round(dados.leadsAtivos * 0.10)), agenda: Math.max(1, Math.round(dados.agendamentosHoje * 0.5)) },
    { dia: "19 Mai", leads: Math.max(4, Math.round(dados.leadsAtivos * 0.18)), agenda: Math.max(1, Math.round(dados.agendamentosHoje * 0.8)) },
    { dia: "20 Mai", leads: Math.max(5, Math.round(dados.leadsAtivos * 0.20)), agenda: Math.max(1, dados.agendamentosHoje) },
    { dia: "21 Mai", leads: Math.max(3, Math.round(dados.leadsAtivos * 0.13)), agenda: Math.max(1, Math.round(dados.agendamentosHoje * 0.5)) },
  ];

  function exportar() {
    const linhas = [
      ["Métrica", "Valor"],
      ["Leads ativos", dados.leadsAtivos],
      ["Agendamentos hoje", dados.agendamentosHoje],
      ["Visitas na loja", dados.visitasLoja],
      ["Vendas pendentes", dados.vendasPendentes],
      ["Leads sem contato", dados.leadsSemContato],
    ];
    const csv = linhas.map((linha) => linha.join(";")).join("\n");
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = "dashboard-flow-sales.csv";
    link.click();
    URL.revokeObjectURL(url);
  }

  return (
    <>
      <div className="mb-5 flex flex-col gap-4 lg:flex-row lg:items-end lg:justify-between">
        <div>
          <h1 className="text-3xl font-black tracking-tight text-slate-950">Dashboard operacional</h1>
          <p className="mt-1 text-sm font-medium text-slate-500">Visão estratégica e operacional da recuperação de vendas</p>
        </div>
        <div className="flex flex-wrap gap-3">
          <button onClick={() => setModal({ titulo: "Período", descricao: "Filtro de período preparado para ajustar todos os indicadores da dashboard." })} className="inline-flex h-11 items-center gap-2 rounded-xl border border-slate-200 bg-white px-4 text-sm font-bold text-slate-700 transition hover:bg-slate-50"><CalendarDays className="h-4 w-4" /> Período 16/05/2024 - 22/05/2024</button>
          <button onClick={() => setModal({ titulo: "Filtros", descricao: "Os filtros da dashboard serão aplicados aos cards, gráficos e relatórios." })} className="inline-flex h-11 items-center gap-2 rounded-xl border border-slate-200 bg-white px-4 text-sm font-bold text-slate-700 transition hover:bg-slate-50"><Filter className="h-4 w-4" /> Filtros</button>
        </div>
      </div>

      <section className="grid gap-4 md:grid-cols-2 xl:grid-cols-6">
        <MetricCard icon={<UsersRound />} label="Leads ativos" value={dados.leadsAtivos} detail="↑ 12,5% vs. anterior" onClick={() => router.push("/dashboard/leads")} />
        <MetricCard icon={<CalendarDays />} label="Agendamentos hoje" value={dados.agendamentosHoje} detail="↑ 8,3% vs. ontem" onClick={() => router.push("/dashboard/agenda")} />
        <MetricCard icon={<Store />} label="Visitas na loja" value={dados.visitasLoja} detail="↑ 11,8% vs. ontem" onClick={() => router.push("/dashboard/leads?etapa=compareceu")} />
        <MetricCard icon={<DollarSign />} label="Vendas pendentes" value={dados.vendasPendentes} detail="↓ 4,5% vs. anterior" color="amber" onClick={() => router.push("/dashboard/leads?filtro=venda_pendente")} />
        <MetricCard icon={<BarChart3 />} label="Conversão do mês" valueText="18,6%" detail="↑ 2,7 p.p. vs. anterior" color="green" onClick={() => setModal({ titulo: "Conversão do mês", descricao: "A conversão considera leads ativos, visitas e vendas validadas no período selecionado." })} />
        <MetricCard icon={<AlertTriangle />} label="Leads sem contato" value={dados.leadsSemContato} detail="↑ 9,6% vs. anterior" color="red" onClick={() => router.push("/dashboard/leads?filtro=sem_contato")} />
      </section>

      <section className="mt-5 grid gap-5 xl:grid-cols-[1.45fr_0.95fr_0.9fr]">
        <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
          <div className="mb-4 flex items-center justify-between">
            <h2 className="text-lg font-black text-slate-950">Leads e agendamentos ao longo do tempo</h2>
            <div className="flex items-center gap-2">
              {['diario','semanal','mensal'].map((item) => <button key={item} onClick={() => setPeriodo(item)} className={`rounded-lg px-3 py-2 text-xs font-black capitalize transition ${periodo === item ? 'bg-blue-700 text-white' : 'bg-slate-50 text-slate-600 hover:bg-slate-100'}`}>{item}</button>)}
              <ActionMenu items={[{ label: "Abrir relatório", onClick: () => router.push("/dashboard/relatorios") }, { label: "Exportar gráfico", onClick: exportar }]} />
            </div>
          </div>
          <div className="relative h-[260px] rounded-xl bg-gradient-to-b from-slate-50 to-white p-5">
            <div className="absolute inset-x-8 top-8 border-t border-dashed border-slate-200" />
            <div className="absolute inset-x-8 top-24 border-t border-dashed border-slate-200" />
            <div className="absolute inset-x-8 top-40 border-t border-dashed border-slate-200" />
            <div className="flex h-full items-end gap-4 px-2 pb-6">
              {chart.map((item) => {
                const altura = Math.min(190, Math.max(40, item.leads));
                const altura2 = Math.min(150, Math.max(25, item.agenda * 2));
                return (
                  <button key={item.dia} onClick={() => setModal({ titulo: `Detalhes de ${item.dia}`, descricao: `${item.leads} leads criados e ${item.agenda} agendamentos registrados.` })} className="group flex flex-1 items-end justify-center gap-1">
                    <span className="w-4 rounded-t-lg bg-blue-600 transition group-hover:bg-blue-700" style={{ height: altura }} />
                    <span className="w-4 rounded-t-lg bg-cyan-400 transition group-hover:bg-cyan-500" style={{ height: altura2 }} />
                  </button>
                );
              })}
            </div>
            <div className="absolute bottom-2 left-6 right-6 grid grid-cols-6 text-center text-xs font-bold text-slate-500">
              {chart.map((item) => <span key={item.dia}>{item.dia}</span>)}
            </div>
          </div>
        </div>

        <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
          <h2 className="mb-4 text-lg font-black text-slate-950">Funil de recuperação</h2>
          <div className="space-y-3">
            {funil.map((item) => (
              <button key={item.label} onClick={() => router.push(item.href)} className="w-full rounded-xl bg-slate-50 p-3 text-left transition hover:bg-slate-100">
                <div className="mb-2 flex items-center justify-between text-sm font-black text-slate-800"><span>{item.label}</span><span>{formatarNumero(item.valor)} ({percent(item.valor, dados.leadsAtivos)}%)</span></div>
                <div className="h-3 overflow-hidden rounded-full bg-white"><div className={`h-full rounded-full ${item.cor}`} style={{ width: `${percent(item.valor, dados.leadsAtivos)}%` }} /></div>
              </button>
            ))}
          </div>
        </div>

        <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
          <div className="mb-4 flex items-center gap-2"><AlertTriangle className="h-5 w-5 text-red-600" /><h2 className="text-lg font-black text-slate-950">Ações urgentes</h2></div>
          <Urgent label="Retornar leads sem contato > 3 dias" value={dados.leadsSemContato} color="red" onClick={() => router.push("/dashboard/leads?filtro=sem_contato")} />
          <Urgent label="Validar propostas pendentes" value={dados.vendasPendentes} color="amber" onClick={() => router.push("/dashboard/leads?filtro=venda_pendente")} />
          <Urgent label="Agendamentos de hoje" value={dados.agendamentosHoje} color="blue" onClick={() => router.push("/dashboard/agenda")} />
          <button onClick={() => router.push("/dashboard/leads")} className="mt-4 text-sm font-black text-blue-700 hover:text-blue-800">Ver todos</button>
        </div>
      </section>

      <section className="mt-5 grid gap-5 xl:grid-cols-[0.8fr_1fr_0.8fr_0.95fr]">
        <Panel title="Agenda de hoje" action="Ver agenda" onAction={() => router.push("/dashboard/agenda")}> 
          {dados.agendamentosHoje ? <p className="text-sm font-semibold text-slate-600">{dados.agendamentosHoje} compromisso(s) para hoje.</p> : <p className="text-sm font-semibold text-slate-500">Nenhum agendamento para hoje.</p>}
        </Panel>
        <Panel title="Prévia do Kanban" action="Ver kanban completo" onAction={() => router.push("/dashboard/kanban")}>
          <div className="grid grid-cols-4 gap-2">
            {funil.slice(0,4).map((item) => <button key={item.label} onClick={() => router.push(item.href)} className="rounded-xl bg-slate-50 p-3 text-left hover:bg-slate-100"><p className="text-xs font-black text-slate-600">{item.label}</p><p className="mt-2 text-xl font-black text-slate-950">{item.valor}</p></button>)}
          </div>
        </Panel>
        <Panel title="Conferência de veículos" action="Ir para conferência" onAction={() => router.push("/dashboard/conferencia")}> 
          <div className="grid grid-cols-2 gap-3"><MiniStat label="Pendentes" value={15} /><MiniStat label="Divergências" value={5} /><MiniStat label="Aceitos" value={28} /><MiniStat label="Finalizados" value={48} /></div>
        </Panel>
        <Panel title="Desempenho por unidade" action="Ver relatório completo" onAction={() => router.push("/dashboard/relatorios")}> 
          <div className="flex h-40 items-end gap-3 px-2">
            {(dados.unidades.length ? dados.unidades : [{ nome: "Loja 1" }, { nome: "Loja 2" }, { nome: "Loja 3" }, { nome: "Loja 4" }]).slice(0,4).map((unidade, index) => <button key={unidade.nome} onClick={() => router.push(`/dashboard/leads?loja=${index + 1}`)} className="flex flex-1 flex-col items-center gap-2"><span className="w-9 rounded-t-lg bg-blue-600" style={{ height: 50 + index * 18 }} /><span className="text-xs font-bold text-slate-500">{unidade.nome}</span></button>)}
          </div>
        </Panel>
      </section>

      <section className="mt-5 flex flex-wrap items-center justify-between gap-4 rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
        <FooterMetric label="Total de leads no período" value={dados.leadsAtivos} />
        <FooterMetric label="Total de visitas na loja" value={dados.visitasLoja} />
        <FooterMetric label="Vendas validadas" value={dados.leadsValidados} />
        <FooterMetric label="Ticket médio (R$)" valueText="97.850" />
        <FooterMetric label="Faturamento (R$)" valueText="3.325.900" />
        <button onClick={exportar} className="inline-flex h-12 items-center gap-2 rounded-xl bg-blue-700 px-6 text-sm font-black text-white shadow-lg shadow-blue-700/20 transition hover:bg-blue-800"><Download className="h-4 w-4" /> Exportar relatório</button>
      </section>

      {modal ? <Modal titulo={modal.titulo} descricao={modal.descricao} href={modal.href} onClose={() => setModal(null)} /> : null}
    </>
  );
}

function MetricCard({ icon, label, value, valueText, detail, color = "blue", onClick }: { icon: React.ReactNode; label: string; value?: number; valueText?: string; detail: string; color?: "blue" | "green" | "amber" | "red"; onClick: () => void }) {
  const cls = { blue: "bg-blue-50 text-blue-700", green: "bg-emerald-50 text-emerald-700", amber: "bg-amber-50 text-amber-700", red: "bg-red-50 text-red-700" }[color];
  return <button onClick={onClick} className="rounded-2xl border border-slate-200 bg-white p-5 text-left shadow-sm transition hover:-translate-y-0.5 hover:shadow-md"><div className={`mb-3 flex h-12 w-12 items-center justify-center rounded-2xl ${cls}`}>{icon}</div><p className="text-sm font-black text-slate-500">{label}</p><strong className="mt-2 block text-3xl font-black text-slate-950">{valueText || formatarNumero(value || 0)}</strong><p className="mt-2 text-xs font-bold text-emerald-600">{detail}</p></button>;
}
function Urgent({ label, value, color, onClick }: { label: string; value: number; color: "red" | "amber" | "blue"; onClick: () => void }) { const cls = { red: "bg-red-50 text-red-700", amber: "bg-amber-50 text-amber-700", blue: "bg-blue-50 text-blue-700" }[color]; return <button onClick={onClick} className="mb-3 flex w-full items-center justify-between rounded-xl bg-slate-50 px-4 py-3 text-left text-sm font-bold text-slate-700 transition hover:bg-slate-100"><span>{label}</span><span className={`rounded-full px-3 py-1 text-xs font-black ${cls}`}>{value}</span></button>; }
function Panel({ title, action, onAction, children }: { title: string; action: string; onAction: () => void; children: React.ReactNode }) { return <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm"><div className="mb-4 flex items-center justify-between"><h2 className="text-lg font-black text-slate-950">{title}</h2><button onClick={onAction} className="text-xs font-black text-blue-700 hover:text-blue-800">{action}</button></div>{children}</div>; }
function MiniStat({ label, value }: { label: string; value: number }) { return <button className="rounded-xl border border-slate-100 bg-slate-50 p-4 text-left transition hover:bg-slate-100"><p className="text-xs font-bold text-slate-500">{label}</p><p className="mt-2 text-3xl font-black text-slate-950">{value}</p></button>; }
function FooterMetric({ label, value, valueText }: { label: string; value?: number; valueText?: string }) { return <div className="min-w-[160px]"><p className="text-sm font-bold text-slate-500">{label}</p><p className="mt-1 text-2xl font-black text-slate-950">{valueText || formatarNumero(value || 0)}</p></div>; }
function Modal({ titulo, descricao, href, onClose }: { titulo: string; descricao: string; href?: string; onClose: () => void }) { const router = useRouter(); return <div className="fixed inset-0 z-[9998] flex items-center justify-center bg-slate-950/30 px-4 backdrop-blur-sm"><div className="w-full max-w-md rounded-2xl bg-white p-6 shadow-2xl"><h2 className="text-xl font-black text-slate-950">{titulo}</h2><p className="mt-3 text-sm leading-6 text-slate-600">{descricao}</p><div className="mt-6 flex justify-end gap-3"><button onClick={onClose} className="h-11 rounded-xl border border-slate-200 px-4 text-sm font-bold text-slate-700">Fechar</button>{href ? <button onClick={() => router.push(href)} className="h-11 rounded-xl bg-blue-700 px-4 text-sm font-bold text-white">Abrir</button> : null}</div></div></div>; }
