import Link from "next/link";

export function ModulePlaceholder({ titulo, descricao, acoes }: { titulo: string; descricao: string; acoes?: { label: string; href: string }[] }) {
  return (
    <section className="rounded-2xl border border-slate-200 bg-white p-8 shadow-sm">
      <h1 className="text-3xl font-black tracking-tight text-slate-950">{titulo}</h1>
      <p className="mt-2 max-w-3xl text-sm font-medium leading-6 text-slate-500">{descricao}</p>
      {acoes?.length ? (
        <div className="mt-6 flex flex-wrap gap-3">
          {acoes.map((acao) => (
            <Link key={acao.href} href={acao.href} className="inline-flex h-11 items-center rounded-xl border border-slate-200 bg-white px-4 text-sm font-black text-slate-700 transition hover:bg-slate-50">
              {acao.label}
            </Link>
          ))}
        </div>
      ) : null}
    </section>
  );
}
