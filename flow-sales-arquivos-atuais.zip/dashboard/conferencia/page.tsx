import { ModulePlaceholder } from "@/components/dashboard/ModulePlaceholder";
export default function Page() { return <ModulePlaceholder titulo="Conferência de veículos" descricao="Módulo preparado para conferência de estoque, divergências e validações de veículos." acoes={[{ label: "Voltar ao dashboard", href: "/dashboard" }]} />; }
