import { ModulePlaceholder } from "@/components/dashboard/ModulePlaceholder";
export default function Page() { return <ModulePlaceholder titulo="Kanban" descricao="Pipeline preparado para organizar os leads por etapa, com movimentação conectada ao CRM." acoes={[{ label: "Ver leads", href: "/dashboard/leads" }]} />; }
