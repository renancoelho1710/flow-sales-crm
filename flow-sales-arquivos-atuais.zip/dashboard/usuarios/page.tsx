import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { UsuariosClient } from "./UsuariosClient";

export default async function UsuariosPage() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect("/login");

  const { data: usuarioAtual } = await supabase
    .from("usuarios_internos")
    .select("id, perfil")
    .eq("auth_user_id", user.id)
    .single();

  if (!usuarioAtual || !["adm", "suporte"].includes(usuarioAtual.perfil)) redirect("/dashboard");

  const [{ data: usuarios }, { data: unidades }, { data: modulos }, { data: permissoes }] = await Promise.all([
    supabase.from("usuarios_internos").select("id, auth_user_id, nome, email, perfil, ativo, telefone, cargo, avatar_url, unidade_padrao_id, recebe_leads, status_operacional, status_administrativo, status_administrativo_motivo, em_ferias, ferias_inicio, ferias_fim, motivo_ferias, ultimo_lead_recebido_em, criado_em, atualizado_em, unidade:unidade_padrao_id(id,nome,codigo)").order("nome"),
    supabase.from("unidades").select("id, nome, codigo").eq("ativa", true).order("codigo"),
    supabase.from("modulos_sistema").select("chave, nome, ordem").eq("ativo", true).order("ordem"),
    supabase.from("usuario_permissoes").select("usuario_id, modulo_chave, permitido"),
  ]);

  const usuariosComPermissoes = (usuarios || []).map((usuario: any) => ({
    ...usuario,
    permissoes: Object.fromEntries((permissoes || []).filter((p: any) => p.usuario_id === usuario.id).map((p: any) => [p.modulo_chave, p.permitido])),
  }));

  return <UsuariosClient usuariosIniciais={usuariosComPermissoes} unidades={unidades || []} modulos={modulos || []} />;
}
