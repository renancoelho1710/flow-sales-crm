"use client";

import type React from "react";
import { FormEvent, useMemo, useState } from "react";
import { CalendarDays, Download, Filter, Lock, Plus, Search, Shield, UserCheck, UserRound, UserX, Wifi } from "lucide-react";
import { AvatarStatus } from "@/components/dashboard/AvatarStatus";
import { ActionMenu } from "@/components/dashboard/ActionMenu";
import { StatusBadge, statusCor, statusLabel } from "@/components/dashboard/StatusBadge";

type Usuario = {
  id: string;
  auth_user_id?: string | null;
  nome: string;
  email: string;
  perfil: "adm" | "suporte" | "colaborador";
  ativo: boolean;
  telefone?: string | null;
  cargo?: string | null;
  avatar_url?: string | null;
  unidade_padrao_id?: string | null;
  unidade?: { id: string; nome: string; codigo: string } | null;
  recebe_leads: boolean;
  status_operacional: string;
  status_administrativo: string;
  status_administrativo_motivo?: string | null;
  em_ferias: boolean;
  ferias_inicio?: string | null;
  ferias_fim?: string | null;
  motivo_ferias?: string | null;
  ultimo_lead_recebido_em?: string | null;
  criado_em: string;
  atualizado_em: string;
  permissoes?: Record<string, boolean>;
};

type Unidade = { id: string; nome: string; codigo: string };
type Modulo = { chave: string; nome: string; ordem: number };

function formatarData(valor?: string | null) {
  if (!valor) return "—";
  const data = new Date(valor);
  if (Number.isNaN(data.getTime())) return "—";
  return new Intl.DateTimeFormat("pt-BR", { day: "2-digit", month: "2-digit", year: "2-digit", hour: "2-digit", minute: "2-digit" }).format(data);
}

function normalizar(valor: unknown) {
  return String(valor || "").toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");
}

export function UsuariosClient({ usuariosIniciais, unidades, modulos }: { usuariosIniciais: Usuario[]; unidades: Unidade[]; modulos: Modulo[] }) {
  const [usuarios, setUsuarios] = useState<Usuario[]>(usuariosIniciais);
  const [selecionado, setSelecionado] = useState<Usuario | null>(usuariosIniciais[0] || null);
  const [busca, setBusca] = useState("");
  const [perfil, setPerfil] = useState("todos");
  const [status, setStatus] = useState("todos");
  const [recebe, setRecebe] = useState("todos");
  const [loja, setLoja] = useState("todas");
  const [modalCadastro, setModalCadastro] = useState(false);
  const [modalFerias, setModalFerias] = useState<Usuario | null>(null);
  const [salvando, setSalvando] = useState(false);
  const [mensagem, setMensagem] = useState("");

  const filtrados = useMemo(() => {
    const termo = normalizar(busca);
    return usuarios.filter((u) => {
      const texto = normalizar([u.nome, u.email, u.telefone, u.cargo, u.unidade?.nome].join(" "));
      return (!termo || texto.includes(termo)) && (perfil === "todos" || u.perfil === perfil) && (status === "todos" || u.status_administrativo === status || u.status_operacional === status) && (recebe === "todos" || String(u.recebe_leads) === recebe) && (loja === "todas" || u.unidade_padrao_id === loja);
    });
  }, [usuarios, busca, perfil, status, recebe, loja]);

  const metrics = {
    total: usuarios.length,
    ativos: usuarios.filter((u) => u.ativo).length,
    recebendo: usuarios.filter((u) => u.recebe_leads).length,
    bloqueados: usuarios.filter((u) => !u.ativo || u.status_administrativo === "bloqueado").length,
    online: usuarios.filter((u) => u.status_operacional === "disponivel" || u.status_operacional === "em_atendimento" || u.status_operacional === "em_ligacao").length,
  };

  async function atualizar(payload: Record<string, unknown>) {
    setSalvando(true);
    const resposta = await fetch("/api/usuarios", { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload) });
    const json = await resposta.json();
    setSalvando(false);
    if (!json.ok) { alert(json.erro || "Não foi possível atualizar."); return; }
    setUsuarios((lista) => lista.map((u) => u.id === json.usuario.id ? json.usuario : u));
    setSelecionado(json.usuario);
    setMensagem("Atualização salva.");
    setTimeout(() => setMensagem(""), 1600);
  }

  async function criarUsuario(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setSalvando(true);
    const form = new FormData(event.currentTarget);
    const payload = Object.fromEntries(form.entries()) as Record<string, string>;
    const resposta = await fetch("/api/usuarios", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ ...payload, recebe_leads: form.get("recebe_leads") === "on" }) });
    const json = await resposta.json();
    setSalvando(false);
    if (!json.ok) { alert(json.erro || "Não foi possível cadastrar."); return; }
    setUsuarios((lista) => [json.usuario, ...lista]);
    setSelecionado(json.usuario);
    setModalCadastro(false);
  }

  async function salvarFerias(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!modalFerias) return;
    const form = new FormData(event.currentTarget);
    await atualizar({ id: modalFerias.id, acao: "ferias", ferias_inicio: form.get("ferias_inicio"), ferias_fim: form.get("ferias_fim"), motivo_ferias: form.get("motivo_ferias") });
    setModalFerias(null);
  }

  function exportar() {
    const csv = [["Nome", "Email", "Perfil", "Ativo", "Recebe leads", "Status administrativo"], ...filtrados.map((u) => [u.nome, u.email, u.perfil, u.ativo ? "Sim" : "Não", u.recebe_leads ? "Sim" : "Não", statusLabel(u.status_administrativo)])].map((l) => l.join(";")).join("\n");
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a"); a.href = url; a.download = "usuarios-flow-sales.csv"; a.click(); URL.revokeObjectURL(url);
  }

  return (
    <>
      <div className="mb-5 flex flex-col gap-4 lg:flex-row lg:items-end lg:justify-between"><div><h1 className="text-3xl font-black tracking-tight text-slate-950">Gestão de usuários</h1><p className="mt-1 text-sm font-medium text-slate-500">Gerencie acessos, perfis, permissões e status operacional da equipe.</p></div><div className="flex flex-wrap gap-3"><button onClick={exportar} className="inline-flex h-11 items-center gap-2 rounded-xl border border-slate-200 bg-white px-5 text-sm font-black text-slate-700 hover:bg-slate-50"><Download className="h-4 w-4" /> Exportar</button><button onClick={() => alert("Importação de usuários preparada para planilha controlada.")} className="inline-flex h-11 items-center gap-2 rounded-xl border border-slate-200 bg-white px-5 text-sm font-black text-slate-700 hover:bg-slate-50">Importar</button><button onClick={() => setModalCadastro(true)} className="inline-flex h-11 items-center gap-2 rounded-xl bg-blue-700 px-5 text-sm font-black text-white shadow-lg shadow-blue-700/20 hover:bg-blue-800"><Plus className="h-4 w-4" /> Cadastrar usuário</button></div></div>

      <section className="mb-4 grid gap-3 xl:grid-cols-[1fr_1fr_1fr_1fr_1fr_1.4fr_auto]"><Select value={loja} onChange={setLoja} options={[{ value: "todas", label: "Unidade: todas" }, ...unidades.map((u) => ({ value: u.id, label: u.nome }))]} /><Select value={perfil} onChange={setPerfil} options={[{ value: "todos", label: "Perfil: todos" }, { value: "adm", label: "ADM" }, { value: "suporte", label: "Suporte" }, { value: "colaborador", label: "Colaborador" }]} /><Select value={status} onChange={setStatus} options={[{ value: "todos", label: "Status: todos" }, { value: "disponivel", label: "Disponível" }, { value: "ferias", label: "Férias" }, { value: "atestado", label: "Atestado" }, { value: "feedback", label: "Feedback" }, { value: "bloqueado", label: "Bloqueado" }]} /><Select value={recebe} onChange={setRecebe} options={[{ value: "todos", label: "Recebe leads: todos" }, { value: "true", label: "Sim" }, { value: "false", label: "Não" }]} /><button onClick={() => alert("Filtros avançados preparados para permissões, último acesso e unidade.")} className="inline-flex h-11 items-center justify-center gap-2 rounded-xl border border-slate-200 bg-white px-4 text-sm font-black text-slate-700"><Filter className="h-4 w-4" /> Filtros</button><div className="relative"><Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" /><input value={busca} onChange={(e) => setBusca(e.target.value)} placeholder="Buscar usuário..." className="h-11 w-full rounded-xl border border-slate-200 bg-white pl-10 pr-3 text-sm font-semibold outline-none focus:border-blue-600 focus:ring-4 focus:ring-blue-100" /></div><button onClick={() => { setBusca(""); setPerfil("todos"); setStatus("todos"); setRecebe("todos"); setLoja("todas"); }} className="h-11 rounded-xl border border-slate-200 bg-white px-4 text-sm font-black text-slate-700 hover:bg-slate-50">Limpar filtros</button></section>

      <section className="mb-4 grid gap-4 md:grid-cols-2 xl:grid-cols-5"><Metric icon={<UserRound />} label="Total de usuários" value={metrics.total} /><Metric icon={<UserCheck />} label="Usuários ativos" value={metrics.ativos} color="green" /><Metric icon={<CalendarDays />} label="Recebendo leads" value={metrics.recebendo} /><Metric icon={<Lock />} label="Bloqueados" value={metrics.bloqueados} color="red" /><Metric icon={<Wifi />} label="Usuários online" value={metrics.online} color="purple" /></section>

      <section className="grid gap-5 xl:grid-cols-[1.55fr_0.65fr]"><div className="rounded-2xl border border-slate-200 bg-white shadow-sm"><div className="flex items-center gap-2 border-b border-slate-200 px-5 py-4"><UserRound className="h-5 w-5 text-blue-700" /><h2 className="font-black text-slate-950">Usuários</h2><span className="rounded-full bg-slate-100 px-2 py-1 text-xs font-black text-slate-600">{filtrados.length}</span></div><div className="overflow-x-auto"><table className="w-full min-w-[960px] text-left text-sm"><thead className="bg-slate-50 text-xs font-black uppercase tracking-[0.14em] text-slate-500"><tr><th className="px-5 py-4">Nome</th><th className="px-5 py-4">Unidade</th><th className="px-5 py-4">Perfil</th><th className="px-5 py-4">Recebe leads</th><th className="px-5 py-4">Status adm.</th><th className="px-5 py-4">Status 3CX</th><th className="px-5 py-4">Último acesso</th><th className="px-5 py-4">Ações</th></tr></thead><tbody className="divide-y divide-slate-100">{filtrados.map((u) => <tr key={u.id} onClick={() => setSelecionado(u)} className={`cursor-pointer transition hover:bg-blue-50/40 ${selecionado?.id === u.id ? "bg-blue-50" : ""}`}><td className="px-5 py-4"><div className="flex items-center gap-3"><AvatarStatus nome={u.nome} avatarUrl={u.avatar_url} status={u.status_operacional} /><div><p className="font-black text-slate-950">{u.nome}</p><p className="text-xs font-semibold text-slate-500">{u.email}</p></div></div></td><td className="px-5 py-4 font-semibold text-slate-600">{u.unidade?.nome || "—"}</td><td className="px-5 py-4"><StatusBadge texto={u.perfil} tipo={u.perfil === "adm" ? "purple" : u.perfil === "suporte" ? "amber" : "blue"} /></td><td className="px-5 py-4"><StatusBadge texto={u.recebe_leads ? "Sim" : "Não"} tipo={u.recebe_leads ? "green" : "red"} /></td><td className="px-5 py-4"><StatusBadge texto={statusLabel(u.status_administrativo)} tipo={statusCor(u.status_administrativo) as any} /></td><td className="px-5 py-4"><StatusBadge texto={statusLabel(u.status_operacional)} tipo={statusCor(u.status_operacional) as any} /></td><td className="px-5 py-4 text-slate-600">{formatarData(u.atualizado_em)}</td><td className="px-5 py-4" onClick={(e) => e.stopPropagation()}><ActionMenu items={[{ label: u.ativo ? "Desativar acesso" : "Ativar acesso", onClick: () => atualizar({ id: u.id, acao: "ativo", ativo: !u.ativo }), danger: u.ativo }, { label: u.recebe_leads ? "Parar de receber leads" : "Receber leads", onClick: () => atualizar({ id: u.id, acao: "recebe_leads", recebe_leads: !u.recebe_leads }), disabled: u.status_administrativo !== "disponivel" }, { label: "Marcar férias", onClick: () => setModalFerias(u) }, { label: "Bloquear usuário", onClick: () => atualizar({ id: u.id, acao: "status_administrativo", status_administrativo: "bloqueado" }), danger: true }, { label: "Resetar senha", onClick: () => atualizar({ id: u.id, acao: "resetar_senha" }) }]} /></td></tr>)}</tbody></table></div></div>
        <UserDetails usuario={selecionado} modulos={modulos} salvando={salvando} onPermissao={(modulo, permitido) => selecionado && atualizar({ id: selecionado.id, acao: "permissao", modulo_chave: modulo, permitido })} onRecebe={() => selecionado && atualizar({ id: selecionado.id, acao: "recebe_leads", recebe_leads: !selecionado.recebe_leads })} onStatusAdm={(statusAdm) => selecionado && atualizar({ id: selecionado.id, acao: "status_administrativo", status_administrativo: statusAdm })} onFerias={() => selecionado && setModalFerias(selecionado)} />
      </section>

      {mensagem ? <div className="fixed bottom-6 right-6 z-[9999] rounded-xl bg-slate-950 px-4 py-3 text-sm font-black text-white shadow-2xl">{mensagem}</div> : null}
      {modalCadastro ? <Modal titulo="Cadastrar usuário" onClose={() => setModalCadastro(false)}><form onSubmit={criarUsuario} className="grid gap-4"><Input name="nome" label="Nome" required /><Input name="email" label="E-mail" type="email" required /><Input name="senha" label="Senha temporária" type="password" required /><Input name="telefone" label="Telefone" /><Input name="cargo" label="Cargo" /><SelectField name="perfil" label="Perfil" options={["adm", "suporte", "colaborador"].map((p) => ({ value: p, label: p }))} /><SelectField name="unidade_padrao_id" label="Unidade padrão" options={[{ value: "", label: "Sem unidade" }, ...unidades.map((u) => ({ value: u.id, label: u.nome }))]} /><label className="flex items-center gap-2 text-sm font-black text-slate-700"><input type="checkbox" name="recebe_leads" className="h-4 w-4" /> Recebe leads</label><button disabled={salvando} className="h-12 rounded-xl bg-blue-700 text-sm font-black text-white disabled:bg-slate-400">Cadastrar</button></form></Modal> : null}
      {modalFerias ? <Modal titulo={`Férias: ${modalFerias.nome}`} onClose={() => setModalFerias(null)}><form onSubmit={salvarFerias} className="grid gap-4"><Input name="ferias_inicio" label="Início" type="date" required /><Input name="ferias_fim" label="Fim" type="date" required /><Input name="motivo_ferias" label="Motivo/observação" /><div className="rounded-xl border border-amber-200 bg-amber-50 p-4 text-sm font-black text-amber-800">Ao marcar férias, o usuário deixa de receber leads automaticamente.</div><button disabled={salvando} className="h-12 rounded-xl bg-blue-700 text-sm font-black text-white disabled:bg-slate-400">Salvar férias</button></form></Modal> : null}
    </>
  );
}

function Select({ value, onChange, options }: { value: string; onChange: (v: string) => void; options: { value: string; label: string }[] }) { return <select value={value} onChange={(e) => onChange(e.target.value)} className="h-11 rounded-xl border border-slate-200 bg-white px-3 text-sm font-bold text-slate-700 outline-none focus:border-blue-600 focus:ring-4 focus:ring-blue-100">{options.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}</select>; }
function Metric({ icon, label, value, color = "blue" }: { icon: React.ReactNode; label: string; value: number; color?: "blue" | "green" | "red" | "purple" }) { const cls = { blue: "bg-blue-50 text-blue-700", green: "bg-emerald-50 text-emerald-700", red: "bg-red-50 text-red-700", purple: "bg-purple-50 text-purple-700" }[color]; return <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm"><div className={`mb-3 flex h-12 w-12 items-center justify-center rounded-2xl ${cls}`}>{icon}</div><p className="text-sm font-black text-slate-500">{label}</p><p className="mt-2 text-3xl font-black text-slate-950">{value}</p></div>; }
function UserDetails({ usuario, modulos, salvando, onPermissao, onRecebe, onStatusAdm, onFerias }: { usuario: Usuario | null; modulos: Modulo[]; salvando: boolean; onPermissao: (modulo: string, permitido: boolean) => void; onRecebe: () => void; onStatusAdm: (status: string) => void; onFerias: () => void }) { if (!usuario) return <div className="rounded-2xl border border-slate-200 bg-white p-6" />; return <aside className="space-y-4"><section className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm"><div className="mb-5 flex items-start justify-between"><div className="flex items-center gap-4"><AvatarStatus nome={usuario.nome} avatarUrl={usuario.avatar_url} status={usuario.status_operacional} size="lg" /><div><h2 className="text-xl font-black text-slate-950">{usuario.nome}</h2><p className="text-sm text-slate-500">{usuario.email}</p></div></div><StatusBadge texto={usuario.perfil} tipo="blue" /></div><div className="grid gap-3 text-sm"><Info label="Telefone" value={usuario.telefone || "—"} /><Info label="Unidade" value={usuario.unidade?.nome || "—"} /><Info label="Cargo" value={usuario.cargo || "—"} /><Info label="Status 3CX" value={statusLabel(usuario.status_operacional)} /></div><div className="mt-5 grid grid-cols-2 gap-3"><button onClick={onRecebe} disabled={salvando || usuario.status_administrativo !== "disponivel"} className={`h-11 rounded-xl text-sm font-black ${usuario.recebe_leads ? "bg-emerald-50 text-emerald-700" : "bg-red-50 text-red-700"} disabled:opacity-50`}>Recebe leads: {usuario.recebe_leads ? "Sim" : "Não"}</button><button onClick={onFerias} disabled={salvando} className="h-11 rounded-xl bg-purple-50 text-sm font-black text-purple-700">Marcar férias</button></div><label className="mt-4 grid gap-2 text-sm font-black text-slate-700">Status administrativo<select value={usuario.status_administrativo} onChange={(e) => onStatusAdm(e.target.value)} className="h-11 rounded-xl border border-slate-200 bg-white px-3 outline-none"><option value="disponivel">Disponível</option><option value="ferias">Férias</option><option value="atestado">Atestado</option><option value="feedback">Feedback</option><option value="ausente_administrativo">Ausente administrativo</option><option value="bloqueado">Bloqueado</option></select></label></section><section className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm"><div className="mb-4 flex items-center justify-between"><h3 className="font-black text-slate-950">Bloqueio de acesso</h3><Shield className="h-5 w-5 text-slate-400" /></div><div className="grid grid-cols-2 gap-2">{modulos.map((m) => { const permitido = Boolean(usuario.permissoes?.[m.chave]); return <button key={m.chave} disabled={salvando} onClick={() => onPermissao(m.chave, !permitido)} className="flex items-center justify-between rounded-xl border border-slate-100 bg-slate-50 px-3 py-2 text-left text-xs font-black text-slate-700 hover:bg-blue-50"><span>{m.nome}</span><span className={`rounded-full px-2 py-1 ${permitido ? "bg-emerald-100 text-emerald-700" : "bg-red-100 text-red-700"}`}>{permitido ? "Permitido" : "Negado"}</span></button>; })}</div></section><section className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm"><h3 className="mb-4 font-black text-slate-950">Últimas ações</h3><Info label="Última atualização" value={formatarData(usuario.atualizado_em)} /><Info label="Último lead recebido" value={formatarData(usuario.ultimo_lead_recebido_em)} /></section></aside>; }
function Info({ label, value }: { label: string; value: string }) { return <div className="flex items-center justify-between gap-4 border-b border-slate-100 py-2 last:border-0"><span className="text-slate-500">{label}</span><strong className="text-right text-slate-800">{value}</strong></div>; }
function Modal({ titulo, children, onClose }: { titulo: string; children: React.ReactNode; onClose: () => void }) { return <div className="fixed inset-0 z-[9998] flex items-center justify-center bg-slate-950/30 px-4 backdrop-blur-sm"><div className="w-full max-w-lg rounded-2xl bg-white p-6 shadow-2xl"><div className="mb-5 flex items-center justify-between"><h2 className="text-xl font-black text-slate-950">{titulo}</h2><button onClick={onClose}>×</button></div>{children}</div></div>; }
function Input({ name, label, type = "text", required = false }: { name: string; label: string; type?: string; required?: boolean }) { return <label className="grid gap-2 text-sm font-black text-slate-700">{label}<input name={name} type={type} required={required} className="h-11 rounded-xl border border-slate-300 px-3 outline-none focus:border-blue-600 focus:ring-4 focus:ring-blue-100" /></label>; }
function SelectField({ name, label, options }: { name: string; label: string; options: { value: string; label: string }[] }) { return <label className="grid gap-2 text-sm font-black text-slate-700">{label}<select name={name} className="h-11 rounded-xl border border-slate-300 px-3 outline-none focus:border-blue-600 focus:ring-4 focus:ring-blue-100">{options.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}</select></label>; }
