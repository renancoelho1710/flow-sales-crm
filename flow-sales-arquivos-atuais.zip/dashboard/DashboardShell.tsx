"use client";

import type React from "react";
import Image from "next/image";
import Link from "next/link";
import { usePathname, useRouter, useSearchParams } from "next/navigation";
import { useEffect, useMemo, useRef, useState } from "react";
import {
  Bell,
  CalendarDays,
  Car,
  ChevronDown,
  CircleHelp,
  DatabaseZap,
  FileBarChart,
  Home,
  KanbanSquare,
  LogOut,
  Megaphone,
  PhoneCall,
  Search,
  Settings,
  ShieldCheck,
  Store,
  UsersRound,
  WalletCards,
  X,
} from "lucide-react";
import { createClient } from "@/lib/supabase/client";
import { AvatarStatus } from "@/components/dashboard/AvatarStatus";
import { statusLabel } from "@/components/dashboard/StatusBadge";

type UsuarioShell = {
  nome: string;
  email: string;
  perfil: string;
  cargo?: string | null;
  avatar_url?: string | null;
  status_operacional?: string | null;
  status_administrativo?: string | null;
};

type Unidade = {
  id: string;
  nome: string;
  codigo: string;
};

type Notificacao = {
  id: string;
  titulo: string;
  descricao: string;
  href: string;
  prioridade: "baixa" | "media" | "alta";
};

type MenuItem = {
  id: string;
  label: string;
  href?: string;
  icon: React.ElementType;
  filhos?: { id: string; label: string; href: string }[];
};

const menuItems: MenuItem[] = [
  { id: "dashboard", label: "Dashboard", href: "/dashboard", icon: Home },
  {
    id: "leads",
    label: "Leads",
    icon: UsersRound,
    filhos: [
      { id: "leads-lista", label: "Gestão de Leads", href: "/dashboard/leads" },
      { id: "kanban", label: "Kanban", href: "/dashboard/kanban" },
      { id: "c2s", label: "Importação C2S", href: "/dashboard/c2s" },
      { id: "distribuicao", label: "Distribuição", href: "/dashboard/distribuicao" },
    ],
  },
  { id: "kanban", label: "Kanban", href: "/dashboard/kanban", icon: KanbanSquare },
  { id: "agenda", label: "Agenda", href: "/dashboard/agenda", icon: CalendarDays },
  { id: "3cx", label: "Controle 3CX", href: "/dashboard/3cx", icon: PhoneCall },
  { id: "campanhas", label: "Campanhas", href: "/dashboard/campanhas", icon: Megaphone },
  { id: "simulador", label: "Simulador", href: "/dashboard/simulador", icon: WalletCards },
  { id: "conferencia", label: "Conferência", href: "/dashboard/conferencia", icon: Car },
  { id: "usuarios", label: "Gestão de usuários", href: "/dashboard/usuarios", icon: ShieldCheck },
  { id: "relatorios", label: "Relatórios", href: "/dashboard/relatorios", icon: FileBarChart },
  { id: "configuracoes", label: "Configurações", href: "/dashboard/configuracoes", icon: Settings },
];

function prioridadeClasse(prioridade: Notificacao["prioridade"]) {
  if (prioridade === "alta") return "bg-red-50 text-red-700 ring-red-100";
  if (prioridade === "media") return "bg-amber-50 text-amber-700 ring-amber-100";
  return "bg-blue-50 text-blue-700 ring-blue-100";
}

export function DashboardShell({
  usuario,
  unidades,
  notificacoes,
  children,
}: {
  usuario: UsuarioShell;
  unidades: Unidade[];
  notificacoes: Notificacao[];
  children: React.ReactNode;
}) {
  const pathname = usePathname();
  const router = useRouter();
  const searchParams = useSearchParams();
  const supabase = createClient();
  const menuRef = useRef<HTMLDivElement | null>(null);
  const scrollRef = useRef<HTMLDivElement | null>(null);
  const timerRef = useRef<number | null>(null);

  const [menuAberto, setMenuAberto] = useState(false);
  const [submenus, setSubmenus] = useState<Record<string, boolean>>({});
  const [buscaGlobal, setBuscaGlobal] = useState(searchParams.get("busca") || "");
  const [loja, setLoja] = useState(searchParams.get("loja") || "todas");
  const [painelNotificacoes, setPainelNotificacoes] = useState(false);
  const [menuUsuario, setMenuUsuario] = useState(false);

  const totalNotificacoes = notificacoes.length;

  function fecharMenu() {
    setMenuAberto(false);
    setSubmenus({});
    pararScrollMenu();
  }

  function alternarSubmenu(id: string) {
    setMenuAberto(true);
    setSubmenus((atual) => ({ ...atual, [id]: !atual[id] }));
  }

  function irComFiltros(destino: string, extras?: Record<string, string>) {
    const params = new URLSearchParams();
    if (buscaGlobal.trim()) params.set("busca", buscaGlobal.trim());
    if (loja !== "todas") params.set("loja", loja);
    Object.entries(extras || {}).forEach(([chave, valor]) => {
      if (valor) params.set(chave, valor);
    });
    const query = params.toString();
    router.push(query ? `${destino}?${query}` : destino);
  }

  function buscar(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    irComFiltros("/dashboard/leads");
  }

  async function sair() {
    await supabase.auth.signOut();
    router.push("/login");
    router.refresh();
  }

  function iniciarScrollMenu(direcao: "cima" | "baixo") {
    if (timerRef.current) window.clearInterval(timerRef.current);
    timerRef.current = window.setInterval(() => {
      scrollRef.current?.scrollBy({ top: direcao === "baixo" ? 12 : -12 });
    }, 16);
  }

  function pararScrollMenu() {
    if (timerRef.current) {
      window.clearInterval(timerRef.current);
      timerRef.current = null;
    }
  }

  useEffect(() => {
    return () => pararScrollMenu();
  }, []);

  const menuAtivo = useMemo(() => {
    const atual = menuItems.find((item) => item.href === pathname || item.filhos?.some((filho) => filho.href === pathname));
    return atual?.id || "dashboard";
  }, [pathname]);

  return (
    <main className="min-h-screen bg-slate-50 text-slate-950">
      <aside
        ref={menuRef}
        onMouseEnter={() => setMenuAberto(true)}
        onMouseLeave={fecharMenu}
        className={`fixed left-0 top-0 z-40 h-screen border-r border-slate-200 bg-white shadow-xl shadow-slate-200/70 transition-all duration-300 ${menuAberto ? "w-[260px]" : "w-[76px]"}`}
      >
        <div className="flex h-full flex-col">
          <div className="flex h-[78px] items-center justify-center border-b border-slate-200 px-3">
            {menuAberto ? (
              <Image src="/logo-slogan.png" alt="Flow Sales CRM" width={180} height={54} priority className="h-auto w-[180px] object-contain" />
            ) : (
              <Image src="/logo.png" alt="Flow Sales CRM" width={42} height={42} priority className="h-[42px] w-[42px] object-contain" />
            )}
          </div>

          <div className="relative flex-1 overflow-hidden py-3">
            <div onMouseEnter={() => iniciarScrollMenu("cima")} onMouseLeave={pararScrollMenu} className="absolute left-0 top-0 z-10 h-8 w-full" />
            <div ref={scrollRef} className="h-full overflow-y-auto px-3 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
              <nav className="space-y-1 pb-10 pt-1">
                {menuItems.map((item) => {
                  const Icon = item.icon;
                  const ativo = menuAtivo === item.id;
                  const temFilhos = Boolean(item.filhos?.length);
                  const aberto = Boolean(submenus[item.id]);

                  if (temFilhos) {
                    return (
                      <div key={item.id}>
                        <button
                          type="button"
                          onClick={() => alternarSubmenu(item.id)}
                          className={`flex h-11 w-full items-center rounded-xl px-3 text-sm font-semibold transition ${ativo ? "bg-blue-700 text-white shadow-lg shadow-blue-700/20" : "text-slate-600 hover:bg-slate-100 hover:text-slate-950"} ${menuAberto ? "justify-between" : "justify-center"}`}
                          title={!menuAberto ? item.label : undefined}
                        >
                          <span className={`flex items-center ${menuAberto ? "gap-3" : "gap-0"}`}>
                            <Icon className="h-5 w-5 shrink-0" />
                            {menuAberto ? <span>{item.label}</span> : null}
                          </span>
                          {menuAberto ? <ChevronDown className={`h-4 w-4 transition ${aberto ? "rotate-180" : ""}`} /> : null}
                        </button>
                        {menuAberto && aberto ? (
                          <div className="ml-6 mt-1 space-y-1 border-l border-slate-200 pl-3">
                            {item.filhos?.map((filho) => (
                              <Link key={filho.id} href={filho.href} className={`block rounded-lg px-3 py-2 text-sm font-semibold transition ${pathname === filho.href ? "bg-blue-50 text-blue-700" : "text-slate-600 hover:bg-slate-50 hover:text-slate-950"}`}>
                                {filho.label}
                              </Link>
                            ))}
                          </div>
                        ) : null}
                      </div>
                    );
                  }

                  return (
                    <Link
                      key={item.id}
                      href={item.href || "#"}
                      className={`flex h-11 items-center rounded-xl px-3 text-sm font-semibold transition ${ativo ? "bg-blue-700 text-white shadow-lg shadow-blue-700/20" : "text-slate-600 hover:bg-slate-100 hover:text-slate-950"} ${menuAberto ? "justify-start gap-3" : "justify-center"}`}
                      title={!menuAberto ? item.label : undefined}
                    >
                      <Icon className="h-5 w-5 shrink-0" />
                      {menuAberto ? <span>{item.label}</span> : null}
                    </Link>
                  );
                })}
              </nav>
            </div>
            <div onMouseEnter={() => iniciarScrollMenu("baixo")} onMouseLeave={pararScrollMenu} className="absolute bottom-0 left-0 z-10 h-10 w-full" />
          </div>

          <div className="border-t border-slate-200 p-3">
            <button type="button" onClick={() => router.push("/dashboard/ajuda")} className={`mb-2 flex h-11 w-full items-center rounded-xl text-sm font-semibold text-slate-600 transition hover:bg-slate-100 hover:text-slate-950 ${menuAberto ? "justify-start gap-3 px-3" : "justify-center"}`}>
              <CircleHelp className="h-5 w-5" />
              {menuAberto ? <span>Central de ajuda</span> : null}
            </button>
            <button type="button" onClick={sair} className={`flex h-11 w-full items-center rounded-xl text-sm font-semibold text-slate-600 transition hover:bg-red-50 hover:text-red-700 ${menuAberto ? "justify-start gap-3 px-3" : "justify-center"}`}>
              <LogOut className="h-5 w-5" />
              {menuAberto ? <span>Sair</span> : null}
            </button>
          </div>
        </div>
      </aside>

      <section className={`min-h-screen transition-all duration-300 ${menuAberto ? "pl-[260px]" : "pl-[76px]"}`}>
        <header className="sticky top-0 z-30 border-b border-slate-200 bg-white/92 backdrop-blur">
          <div className="flex h-[78px] items-center justify-between gap-4 px-6">
            <form onSubmit={buscar} className="relative hidden w-full max-w-[560px] lg:block">
              <Search className="absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
              <input
                value={buscaGlobal}
                onChange={(event) => setBuscaGlobal(event.target.value)}
                placeholder="Buscar por leads, clientes, veículos, agendamentos..."
                className="h-11 w-full rounded-xl border border-slate-200 bg-white pl-11 pr-4 text-sm font-medium text-slate-700 outline-none transition focus:border-blue-600 focus:ring-4 focus:ring-blue-100"
              />
            </form>

            <div className="flex flex-1 items-center justify-end gap-3">
              <div className="relative hidden sm:block">
                <Store className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-500" />
                <select
                  value={loja}
                  onChange={(event) => {
                    setLoja(event.target.value);
                    const params = new URLSearchParams(searchParams.toString());
                    if (event.target.value === "todas") params.delete("loja");
                    else params.set("loja", event.target.value);
                    router.push(`${pathname}${params.toString() ? `?${params.toString()}` : ""}`);
                  }}
                  className="h-11 min-w-[240px] rounded-xl border border-slate-200 bg-white pl-10 pr-4 text-sm font-bold text-slate-700 outline-none transition focus:border-blue-600 focus:ring-4 focus:ring-blue-100"
                >
                  <option value="todas">Todas as lojas</option>
                  {unidades.map((unidade) => (
                    <option key={unidade.id} value={unidade.id}>{unidade.nome}</option>
                  ))}
                </select>
              </div>

              <div className="relative">
                <button type="button" onClick={() => setPainelNotificacoes((atual) => !atual)} className="relative flex h-11 w-11 items-center justify-center rounded-xl border border-slate-200 bg-white text-slate-700 transition hover:bg-slate-50">
                  <Bell className="h-5 w-5" />
                  {totalNotificacoes ? <span className="absolute -right-1 -top-1 flex h-5 min-w-5 items-center justify-center rounded-full bg-red-600 px-1 text-[10px] font-black text-white">{totalNotificacoes}</span> : null}
                </button>
                {painelNotificacoes ? (
                  <div className="absolute right-0 top-14 z-50 w-[360px] overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-2xl shadow-slate-900/12">
                    <div className="flex items-center justify-between border-b border-slate-200 px-4 py-3">
                      <strong className="text-sm text-slate-950">Notificações</strong>
                      <button onClick={() => setPainelNotificacoes(false)} className="rounded-lg p-1 hover:bg-slate-100"><X className="h-4 w-4" /></button>
                    </div>
                    <div className="max-h-[360px] overflow-y-auto p-2">
                      {notificacoes.length ? notificacoes.map((notificacao) => (
                        <button key={notificacao.id} type="button" onClick={() => router.push(notificacao.href)} className="block w-full rounded-xl px-3 py-3 text-left transition hover:bg-slate-50">
                          <span className={`mb-2 inline-flex rounded-full px-2 py-1 text-[11px] font-black ring-1 ${prioridadeClasse(notificacao.prioridade)}`}>{notificacao.prioridade}</span>
                          <p className="text-sm font-bold text-slate-900">{notificacao.titulo}</p>
                          <p className="mt-1 text-xs leading-5 text-slate-500">{notificacao.descricao}</p>
                        </button>
                      )) : <p className="px-3 py-6 text-center text-sm font-semibold text-slate-500">Nenhuma notificação no momento.</p>}
                    </div>
                  </div>
                ) : null}
              </div>

              <div className="relative">
                <button type="button" onClick={() => setMenuUsuario((atual) => !atual)} className="flex items-center gap-3 rounded-2xl border border-transparent px-2 py-1 transition hover:border-slate-200 hover:bg-white">
                  <AvatarStatus nome={usuario.nome} avatarUrl={usuario.avatar_url} status={usuario.status_operacional} />
                  <span className="hidden text-left xl:block">
                    <span className="block text-sm font-black text-slate-950">{usuario.nome}</span>
                    <span className="block text-xs text-slate-500">{usuario.cargo || statusLabel(usuario.status_operacional)}</span>
                  </span>
                  <ChevronDown className="hidden h-4 w-4 text-slate-500 xl:block" />
                </button>
                {menuUsuario ? (
                  <div className="absolute right-0 top-14 z-50 w-[260px] overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-2xl shadow-slate-900/12">
                    <div className="border-b border-slate-200 p-4">
                      <p className="text-sm font-black text-slate-950">{usuario.nome}</p>
                      <p className="mt-1 text-xs text-slate-500">{usuario.email}</p>
                      <p className="mt-2 text-xs font-bold text-blue-700">{statusLabel(usuario.status_operacional)}</p>
                    </div>
                    <button onClick={() => router.push("/dashboard/configuracoes")} className="block w-full px-4 py-3 text-left text-sm font-bold text-slate-700 hover:bg-slate-50">Preferências</button>
                    <button onClick={sair} className="block w-full px-4 py-3 text-left text-sm font-bold text-red-700 hover:bg-red-50">Sair</button>
                  </div>
                ) : null}
              </div>
            </div>
          </div>
        </header>

        <div className="px-6 py-6">{children}</div>
      </section>
    </main>
  );
}
