import { ModulePlaceholder } from "@/components/dashboard/ModulePlaceholder";
export default function Page() { return <ModulePlaceholder titulo="Central de ajuda" descricao="Central preparada para suporte interno, dúvidas operacionais e documentação do Flow Sales CRM." acoes={[{ label: "Dashboard", href: "/dashboard" }]} />; }
