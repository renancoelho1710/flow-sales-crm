import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { C2SImportarClient } from "./C2SImportarClient";

export default async function C2SPage() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect("/login");

  const { data: usuario } = await supabase
    .from("usuarios_internos")
    .select("id, nome, perfil")
    .eq("auth_user_id", user.id)
    .single();

  if (!usuario || !["adm", "suporte"].includes(usuario.perfil)) redirect("/dashboard");

  const { data: importacoes } = await supabase
    .from("importacoes_c2s")
    .select("id, total_recebidos, total_importados, total_atualizados, total_sem_telefone, status, criado_em")
    .order("criado_em", { ascending: false })
    .limit(10);

  return <C2SImportarClient importacoes={importacoes || []} />;
}
