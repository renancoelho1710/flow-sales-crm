"use client";

import { useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import { BarChart3, DatabaseZap, Download, PhoneCall, RefreshCw, Search, UploadCloud, Car } from "lucide-react";

type LeadC2S = {
  c2s_id: string | null;
  c2s_internal_id: number | null;
  nome: string;
  telefone: string | null;
  telefone_normalizado: string;
  email: string | null;
  origem: string | null;
  veiculo_interesse: string | null;
  produto?: { marca?: string | null; modelo?: string | null; preco?: string | null; preco_float?: number | null };
  criado_em_c2s: string | null;
};

type Importacao = { id: string; total_recebidos: number; total_importados: number; total_atualizados: number; total_sem_telefone: number; status: string; criado_em: string };

type Resultado = { ok: boolean; total_recebidos?: number; total_importados?: number; total_atualizados?: number; total_sem_telefone?: number; erro?: string };

function formatarData(valor?: string | null) {
  if (!valor) return "—";
  return new Intl.DateTimeFormat("pt-BR", { day: "2-digit", month: "2-digit", year: "2-digit", hour: "2-digit", minute: "2-digit" }).format(new Date(valor));
}
function formatarPreco(valor?: number | null) { if (!valor) return "—"; return new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL", maximumFractionDigits: 0 }).format(valor); }
function normalizar(valor: unknown) { return String(valor || "").toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, ""); }

export function C2SImportarClient({ importacoes }: { importacoes: Importacao[] }) {
  const router = useRouter();
  const [busca, setBusca] = useState("");
  const [leads, setLeads] = useState<LeadC2S[]>([]);
  const [carregando, setCarregando] = useState(true);
  const [importando, setImportando] = useState(false);
  const [resultado, setResultado] = useState<Resultado | null>(null);
  const [erro, setErro] = useState("");

  async function carregar() {
    setCarregando(true); setErro("");
    try {
      const resp = await fetch("/api/c2s/leads", { cache: "no-store" });
      const json = await resp.json();
      if (!json.ok) { setErro(json.erro || "Não foi possível carregar C2S."); setLeads([]); return; }
      setLeads(Array.isArray(json.leads) ? json.leads : []);
    } catch { setErro("Falha ao consultar C2S."); }
    finally { setCarregando(false); }
  }

  async function importar() {
    setImportando(true); setErro(""); setResultado(null);
    try {
      const resp = await fetch("/api/c2s/importar", { method: "POST" });
      const json = await resp.json();
      if (!json.ok) { setErro(json.erro || "Não foi possível importar."); return; }
      setResultado(json);
      await carregar();
    } catch { setErro("Falha ao importar leads do C2S."); }
    finally { setImportando(false); }
  }

  useEffect(() => { carregar(); }, []);

  const filtrados = useMemo(() => {
    const termo = normalizar(busca);
    return leads.filter((lead) => !termo || normalizar([lead.nome, lead.telefone, lead.email, lead.veiculo_interesse, lead.produto?.marca, lead.produto?.modelo].join(" ")).includes(termo));
  }, [busca, leads]);

  const totalSemTelefone = leads.filter((l) => !l.telefone_normalizado).length;
  const totalComEmail = leads.filter((l) => Boolean(l.email)).length;
  const totalVeiculos = leads.filter((l) => Boolean(l.veiculo_interesse)).length;

  function exportar() {
    const csv = [["Nome", "Telefone", "Email", "Veículo", "C2S"], ...filtrados.map((l) => [l.nome, l.telefone || "", l.email || "", l.veiculo_interesse || "", l.c2s_internal_id || ""])].map((linha) => linha.join(";")).join("\n");
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8" });
    const url = URL.createObjectURL(blob); const a = document.createElement("a"); a.href = url; a.download = "leads-c2s.csv"; a.click(); URL.revokeObjectURL(url);
  }

  return (
    <>
      <div className="mb-5 flex flex-col gap-4 lg:flex-row lg:items-end lg:justify-between"><div><h1 className="text-3xl font-black tracking-tight text-slate-950">Importação C2S</h1><p className="mt-1 text-sm font-medium text-slate-500">Consulte, valide e importe leads recebidos pela API Contact2Sale.</p></div><div className="flex flex-wrap gap-3"><button onClick={exportar} className="inline-flex h-11 items-center gap-2 rounded-xl border border-slate-200 bg-white px-5 text-sm font-black text-slate-700 hover:bg-slate-50"><Download className="h-4 w-4" /> Exportar</button><button onClick={carregar} disabled={carregando} className="inline-flex h-11 items-center gap-2 rounded-xl border border-slate-200 bg-white px-5 text-sm font-black text-slate-700 hover:bg-slate-50 disabled:opacity-60"><RefreshCw className={`h-4 w-4 ${carregando ? "animate-spin" : ""}`} /> Atualizar</button><button onClick={importar} disabled={importando} className="inline-flex h-11 items-center gap-2 rounded-xl bg-blue-700 px-5 text-sm font-black text-white shadow-lg shadow-blue-700/20 hover:bg-blue-800 disabled:bg-slate-400"><UploadCloud className="h-4 w-4" /> {importando ? "Importando..." : "Importar leads"}</button></div></div>

      <section className="mb-5 grid gap-4 md:grid-cols-2 xl:grid-cols-4"><Metric icon={<DatabaseZap />} label="Leads no C2S" value={carregando ? "—" : leads.length} /><Metric icon={<PhoneCall />} label="Com telefone" value={carregando ? "—" : leads.length - totalSemTelefone} color="green" /><Metric icon={<BarChart3 />} label="Com e-mail" value={carregando ? "—" : totalComEmail} color="purple" /><Metric icon={<Car />} label="Com veículo" value={carregando ? "—" : totalVeiculos} color="amber" /></section>

      <section className="grid gap-5 xl:grid-cols-[1fr_360px]"><div className="rounded-2xl border border-slate-200 bg-white shadow-sm"><div className="flex flex-col gap-4 border-b border-slate-200 p-5 lg:flex-row lg:items-center lg:justify-between"><h2 className="text-lg font-black text-slate-950">Leads recebidos da API</h2><div className="relative"><Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" /><input value={busca} onChange={(e) => setBusca(e.target.value)} placeholder="Buscar lead" className="h-11 w-full rounded-xl border border-slate-200 bg-white pl-10 pr-3 text-sm font-semibold outline-none focus:border-blue-600 focus:ring-4 focus:ring-blue-100 sm:w-[280px]" /></div></div><div className="overflow-x-auto"><table className="w-full min-w-[940px] text-left text-sm"><thead className="bg-slate-50 text-xs font-black uppercase tracking-[0.14em] text-slate-500"><tr><th className="px-5 py-4">Cliente</th><th className="px-5 py-4">Telefone</th><th className="px-5 py-4">Veículo</th><th className="px-5 py-4">Valor</th><th className="px-5 py-4">C2S</th><th className="px-5 py-4">Recebido</th></tr></thead><tbody className="divide-y divide-slate-100">{carregando ? <tr><td colSpan={6} className="px-5 py-10 text-center font-bold text-slate-500">Carregando...</td></tr> : filtrados.map((lead) => <tr key={lead.c2s_id || String(lead.c2s_internal_id)} onClick={() => router.push(`/dashboard/leads?busca=${encodeURIComponent(lead.telefone || lead.nome)}`)} className="cursor-pointer hover:bg-blue-50/40"><td className="px-5 py-4"><p className="font-black text-slate-950">{lead.nome}</p><p className="text-xs text-slate-500">{lead.email || "—"}</p></td><td className="px-5 py-4 font-bold text-slate-700">{lead.telefone || "—"}</td><td className="max-w-[300px] px-5 py-4"><p className="line-clamp-2 font-bold text-slate-700">{lead.veiculo_interesse || "—"}</p></td><td className="px-5 py-4 font-black text-slate-950">{formatarPreco(lead.produto?.preco_float)}</td><td className="px-5 py-4 text-slate-600">{lead.c2s_internal_id || "—"}</td><td className="px-5 py-4 text-slate-600">{formatarData(lead.criado_em_c2s)}</td></tr>)}</tbody></table></div></div>
        <aside className="space-y-5"><div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm"><h2 className="mb-4 text-lg font-black text-slate-950">Resultado da importação</h2>{erro ? <div className="rounded-xl border border-red-200 bg-red-50 p-4 text-sm font-black text-red-700">{erro}</div> : null}{resultado?.ok ? <div className="space-y-3 rounded-xl border border-emerald-200 bg-emerald-50 p-4 text-sm font-bold text-emerald-800"><Line label="Recebidos" value={resultado.total_recebidos} /><Line label="Importados" value={resultado.total_importados} /><Line label="Atualizados" value={resultado.total_atualizados} /><Line label="Sem telefone" value={resultado.total_sem_telefone} /></div> : <p className="text-sm font-semibold text-slate-500">Clique em importar para gravar os leads no CRM.</p>}</div><div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm"><h2 className="mb-4 text-lg font-black text-slate-950">Últimas importações</h2><div className="space-y-3">{importacoes.map((imp) => <button key={imp.id} className="w-full rounded-xl bg-slate-50 p-3 text-left hover:bg-slate-100"><p className="text-sm font-black text-slate-950">{formatarData(imp.criado_em)}</p><p className="mt-1 text-xs font-bold text-slate-500">{imp.total_importados} importados · {imp.total_atualizados} atualizados</p></button>)}</div></div></aside>
      </section>
    </>
  );
}
function Metric({ icon, label, value, color = "blue" }: { icon: React.ReactNode; label: string; value: number | string; color?: "blue" | "green" | "purple" | "amber" }) { const cls = { blue: "bg-blue-50 text-blue-700", green: "bg-emerald-50 text-emerald-700", purple: "bg-purple-50 text-purple-700", amber: "bg-amber-50 text-amber-700" }[color]; return <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm"><div className={`mb-3 flex h-12 w-12 items-center justify-center rounded-2xl ${cls}`}>{icon}</div><p className="text-sm font-black text-slate-500">{label}</p><p className="mt-2 text-3xl font-black text-slate-950">{value}</p></div>; }
function Line({ label, value }: { label: string; value?: number }) { return <div className="flex items-center justify-between"><span>{label}</span><strong>{value || 0}</strong></div>; }
