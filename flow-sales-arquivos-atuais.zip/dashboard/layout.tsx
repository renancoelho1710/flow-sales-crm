import { redirect } from "next/navigation";
import { DashboardShell } from "@/components/dashboard/DashboardShell";
import { createClient } from "@/lib/supabase/server";

export default async function DashboardLayout({ children }: { children: React.ReactNode }) {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();

  if (!user) redirect("/login");

  const { data: usuario } = await supabase
    .from("usuarios_internos")
    .select("id, nome, email, perfil, cargo, avatar_url, ativo, status_operacional, status_administrativo")
    .eq("auth_user_id", user.id)
    .eq("ativo", true)
    .single();

  if (!usuario) redirect("/login");

  const { data: unidades } = await supabase
    .from("unidades")
    .select("id, nome, codigo")
    .eq("ativa", true)
    .order("codigo", { ascending: true });

  const { count: leadsSemContato } = await supabase
    .from("leads")
    .select("id", { count: "exact", head: true })
    .eq("arquivado", false)
    .in("etapa", ["novo", "primeiro_contato", "segundo_contato"]);

  const { count: vendasPendentes } = await supabase
    .from("leads")
    .select("id", { count: "exact", head: true })
    .eq("venda_pendente_validacao", true)
    .eq("venda_validada", false);

  const notificacoes = [
    leadsSemContato ? {
      id: "leads-sem-contato",
      titulo: "Leads sem contato",
      descricao: `${leadsSemContato} lead(s) aguardando ação comercial.`,
      href: "/dashboard/leads?filtro=sem_contato",
      prioridade: "alta" as const,
    } : null,
    vendasPendentes ? {
      id: "vendas-pendentes",
      titulo: "Vendas pendentes",
      descricao: `${vendasPendentes} venda(s) aguardando validação.`,
      href: "/dashboard/leads?filtro=venda_pendente",
      prioridade: "media" as const,
    } : null,
  ].filter(Boolean) as Array<{ id: string; titulo: string; descricao: string; href: string; prioridade: "baixa" | "media" | "alta" }>;

  return (
    <DashboardShell usuario={usuario} unidades={unidades || []} notificacoes={notificacoes}>
      {children}
    </DashboardShell>
  );
}
